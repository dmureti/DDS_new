Shrimp was carefully crafted to form structured,strong and stylish letterform. Be charming, be a shrimp!

License: Free for commercial use.

https://www.behance.net/antondarri